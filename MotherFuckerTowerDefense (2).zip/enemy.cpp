#include "enemy.h"

//Enemy::Enemy(QObject *parent) : QObject(parent)
Enemy::Enemy(QPoint pos, int lv):QObject(0), _pos(pos),_lv(lv){

}
void Enemy::move(){

}
